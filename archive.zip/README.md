# Pi-CES

Assignment 1 - Connected Embedded Systems